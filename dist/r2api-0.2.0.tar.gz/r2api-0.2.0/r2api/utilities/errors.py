class ParsingError(AttributeError):
    pass

class ConversionError(AttributeError):
    pass